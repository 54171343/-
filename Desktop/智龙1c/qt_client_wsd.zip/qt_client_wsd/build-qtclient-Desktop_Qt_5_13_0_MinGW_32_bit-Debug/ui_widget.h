/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QGroupBox *groupBox;
    QPlainTextEdit *recvEdit;
    QLabel *Image;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *ipEdit;
    QLabel *label_2;
    QLineEdit *portEdit;
    QWidget *widget1;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *connectBt;
    QSpacerItem *horizontalSpacer;
    QPushButton *closeBt;
    QSpacerItem *horizontalSpacer_4;
    QPushButton *clearBt;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(821, 660);
        Widget->setMinimumSize(QSize(700, 660));
        groupBox = new QGroupBox(Widget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(9, 9, 421, 161));
        groupBox->setMinimumSize(QSize(421, 161));
        recvEdit = new QPlainTextEdit(groupBox);
        recvEdit->setObjectName(QString::fromUtf8("recvEdit"));
        recvEdit->setGeometry(QRect(10, 20, 401, 120));
        recvEdit->setMinimumSize(QSize(401, 120));
        recvEdit->setReadOnly(true);
        Image = new QLabel(Widget);
        Image->setObjectName(QString::fromUtf8("Image"));
        Image->setGeometry(QRect(20, 170, 640, 480));
        Image->setMinimumSize(QSize(640, 480));
        Image->setMaximumSize(QSize(640, 480));
        widget = new QWidget(Widget);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(440, 60, 358, 22));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        ipEdit = new QLineEdit(widget);
        ipEdit->setObjectName(QString::fromUtf8("ipEdit"));

        horizontalLayout->addWidget(ipEdit);

        label_2 = new QLabel(widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout->addWidget(label_2);

        portEdit = new QLineEdit(widget);
        portEdit->setObjectName(QString::fromUtf8("portEdit"));

        horizontalLayout->addWidget(portEdit);

        widget1 = new QWidget(Widget);
        widget1->setObjectName(QString::fromUtf8("widget1"));
        widget1->setGeometry(QRect(440, 130, 327, 25));
        horizontalLayout_2 = new QHBoxLayout(widget1);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        connectBt = new QPushButton(widget1);
        connectBt->setObjectName(QString::fromUtf8("connectBt"));

        horizontalLayout_2->addWidget(connectBt);

        horizontalSpacer = new QSpacerItem(38, 18, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        closeBt = new QPushButton(widget1);
        closeBt->setObjectName(QString::fromUtf8("closeBt"));

        horizontalLayout_2->addWidget(closeBt);

        horizontalSpacer_4 = new QSpacerItem(38, 18, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_4);

        clearBt = new QPushButton(widget1);
        clearBt->setObjectName(QString::fromUtf8("clearBt"));

        horizontalLayout_2->addWidget(clearBt);


        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QCoreApplication::translate("Widget", "Widget", nullptr));
        groupBox->setTitle(QCoreApplication::translate("Widget", "\346\270\251\346\271\277\345\272\246", nullptr));
        Image->setText(QString());
        label->setText(QCoreApplication::translate("Widget", "ip\345\234\260\345\235\200", nullptr));
        ipEdit->setText(QCoreApplication::translate("Widget", "192.168.43.100", nullptr));
        label_2->setText(QCoreApplication::translate("Widget", "\347\253\257\345\217\243\345\217\267", nullptr));
        portEdit->setText(QCoreApplication::translate("Widget", "8080", nullptr));
        connectBt->setText(QCoreApplication::translate("Widget", "\350\277\236\346\216\245", nullptr));
        closeBt->setText(QCoreApplication::translate("Widget", "\345\205\263\351\227\255", nullptr));
        clearBt->setText(QCoreApplication::translate("Widget", "\346\270\205\347\251\272", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
