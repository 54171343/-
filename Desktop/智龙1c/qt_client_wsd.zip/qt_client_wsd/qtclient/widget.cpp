#include "widget.h"
#include "ui_widget.h"
#include <QHostAddress>

bool record;

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    tcpSocket = new QTcpSocket();
    client=new QTcpSocket;

    connect(client,SIGNAL(connected()),this,SLOT(sendrequest()));
    connect(client,SIGNAL(readyRead()),this,SLOT(read()));

}
Widget::~Widget()
{
    delete ui;
}

void Widget::readyRead_Slot()
{
    ui->recvEdit->appendPlainText(tcpSocket->readAll());
}

void Widget::connected_Slot()
{
    connect(tcpSocket,SIGNAL(readyRead()),this,SLOT(readyRead_Slot()));
}

void Widget::on_connectBt_clicked()
{
    tcpSocket->connectToHost(ui->ipEdit->text(),ui->portEdit->text().toUInt());
    connect(tcpSocket,SIGNAL(connected()),this,SLOT(connected_Slot()));

    QString ip = "192.168.43.100";
    /* 用于视频传输 */
    client->connectToHost(QHostAddress(ip),8080);
}

void Widget::on_closeBt_clicked()
{
    tcpSocket->close();
}

void Widget::on_clearBt_clicked()
{
    ui->recvEdit->clear();
}




void Widget::sendrequest()
{
    QByteArray block("GET /?action=stream\n\n");
    client->write(block);

    ui->label->setText(tr("connecting..., success"));
}


void Widget::read()
{
    if(client->bytesAvailable()<3000)
        return;

    QByteArray tmpBlock;
    static unsigned const char SOIData[]={0xff,0xd8};
    static unsigned const char EOIData[]={0xff,0xd9};

    QByteArray SOIstr=QByteArray::fromRawData((char *)SOIData,sizeof(SOIData));
    QByteArray EOIstr=QByteArray::fromRawData((char *)EOIData,sizeof(EOIData));

    int SOIPos=0;
    int EOIPos=0;

    mutex.lock();
    tmpBlock=client->readAll();
    block1.append(tmpBlock);//保存实际读到的数据

    if((SOIPos=block1.indexOf(SOIstr))!= -1)
    {
        if((EOIPos=block1.indexOf(EOIstr))!= -1)
        {
            EOIPos += 2;
            if(EOIPos>SOIPos)
            {
                QByteArray ba;
                ba=block1.mid(SOIPos,EOIPos-SOIPos);

                QImage image;
                image.loadFromData(ba);

                int width = image.width(), height = image.height();

                //QImage* qImage=new QImage(qImageBuffer, width, height, QImage::Format_RGB32);

                QPixmap pix;
                pix= pix.fromImage(image);
                //ui->Image->setPixmap(pix.scaled(ui->label->size()));
                ui->Image->setPixmap(pix);
                //delete qImage;

                ba.clear();
            }
            block1.remove(0,EOIPos+1);
        }
    }
    mutex.unlock();
}















