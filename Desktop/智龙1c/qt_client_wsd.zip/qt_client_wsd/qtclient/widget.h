#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTcpSocket>
#include <QMutex>

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr);
    ~Widget();
    QTcpSocket *tcpSocket;

private slots:
    void on_connectBt_clicked();
    void connected_Slot();
    void readyRead_Slot();
    void sendrequest();
    void on_closeBt_clicked();
    void read();

    void on_clearBt_clicked();

private:
    Ui::Widget *ui;
    QTcpSocket *client;
    QByteArray block1;
    QMutex mutex;
};

#endif // WIDGET_H
